<?php
$server ="den1.mysql1.gear.host";
$username = "sistema05";
$password = "Ia2LlJ!?qy34";
$database = "sistema05";

//conexion
$db = mysqli_connect($server,$username,$password,$database);

?>